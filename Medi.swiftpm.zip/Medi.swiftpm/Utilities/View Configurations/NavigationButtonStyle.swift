//
//  File.swift
//
//
//  Created by Shilpee Gupta on 19/04/23.
//

import SwiftUI

struct NavigationButtonStyle: ButtonStyle {
    // MARK: Properties
    
    // Background color of navigation button
    var color: Color
    
    // MARK: Functions
    
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .frame(width: 200, height: 60, alignment: .center)
            .padding()
//            .background(.quaternary, in: Capsule())
            .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                .fill(color)
                .frame(width: 150, height: 50)
                .clipped(), alignment: .center)
            .font(.system(size: 17, weight: .bold, design: .default))
            .foregroundColor(.white)
            .opacity(configuration.isPressed ? 0.5 : 1)
    }
}

struct NavigationButtonStyle_Previews: PreviewProvider {
    static var previews: some View {
        Button(action: { print("Pressed") }) {
            Label("Press Me", systemImage: "star")
        }
        .buttonStyle(NavigationButtonStyle(color: Color.mint))
    }
}
