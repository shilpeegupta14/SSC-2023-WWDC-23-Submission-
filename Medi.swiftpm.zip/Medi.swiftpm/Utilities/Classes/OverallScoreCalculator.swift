//
//  File.swift
//  
//
//  Created by Shilpee Gupta on 19/04/23.
//

import SwiftUI

class OverallScoreCalculator: ObservableObject {
    
    // MARK: Properties
    
    // View Model
    static var shared = OverallScoreCalculator()
    
    @Published var speakingTestResult = Int(11)
    @Published var handwritingTestResult = Int(15)
    
    // MARK: Functions
    
    func calculate() -> Int {
        
        // Properties
        var speakingResultPercantage = Int()
        var handwritingTestPercantage = Int()
        
        speakingResultPercantage = getPercantage(value: speakingTestResult, percentage: 30)
        handwritingTestPercantage = getPercantage(value: handwritingTestResult, percentage: 20)
        
        // Returning the final result.
        return speakingResultPercantage + handwritingTestPercantage
    }
    
    func getPercantage(value: Int, percentage: Int) -> Int {
        return value * percentage/100
    }
    
}
