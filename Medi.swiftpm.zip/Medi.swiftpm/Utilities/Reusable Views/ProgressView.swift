//
//  File.swift
//
//
//  Created by Shilpee Gupta on 19/04/23.
//

import SwiftUI

// Custom Progress View
struct ProgressViews: View {
    
    // MARK: View
    
    var body: some View {
        ZStack {
            
            // Background Rectangle
            Rectangle()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .foregroundColor(.black)
                .opacity(0.7)
                .zIndex(1.0)
            
            VStack {
                
                // Progress Text
                Text("Analyzing...")
                    .font(.system(size: 17, weight: .bold, design: .default))
                
                // Progress View
                ProgressView()
            }
            .background(RoundedRectangle(cornerRadius: 25, style: .continuous)
                .fill(Color(.systemGray4))
                .frame(width: 160, height: 90)
                .clipped(), alignment: .center)
            .zIndex(2.0)
        }
    }
    
}
struct ProgressView_Previews: PreviewProvider {
    static var previews: some View {
        ProgressView()
    }
}
