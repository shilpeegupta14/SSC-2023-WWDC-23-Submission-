//
//  File.swift
//
//
//  Created by Shilpee Gupta on 19/04/23.
//

import CoreML
import SoundAnalysis
import AVKit

class AudioClassificationProvider : NSObject, SNResultsObserving {
    
    var model: MLModel!
    
    //Access the bundled CoreML model
    let soundClassifier = try? SpeakingML()
    
    
    // MARK: Functions
    
    func request(_ request: SNRequest, didProduce result: SNResult) {
        // Getting the AphasiaVoice classification.
        guard let result = result as? SNClassificationResult,
              let aphasiaVoicePrediction = result.classification(forIdentifier: "AphasiaVoice") else { return }
        
        // Getting the result as a percentage.
        let confidence = aphasiaVoicePrediction.confidence * 100.0
        
        // Informing the OverallScoreCalculator to update the speakingTestResult variable.
        OverallScoreCalculator.shared.speakingTestResult = Int(confidence)
    }
    
    func request(_ request: SNRequest, didFailWithError error: Error) {
        print("The the analysis failed: \(error.localizedDescription)")
    }
    
    func requestDidComplete(_ request: SNRequest) {
        print("The request completed successfully!")
    }
    
    public func predictionResult(audioFileUrl: URL) {
//        var model: MLModel!
//
//        //Access the bundled CoreML model
//        let soundClassifier = try? SpeakingML()
        model = soundClassifier?.model
        
        do {
            // Creating a new audio file analyzer.
            let audioFileAnalyzer = try SNAudioFileAnalyzer(url: audioFileUrl)
            
            // Creating a new observer that will be notified of analysis results.
            let resultsObserver = AudioClassificationProvider()
            
            do {
                // Preparing a new request for the trained model.
                let request = try SNClassifySoundRequest(mlModel: model)
                try audioFileAnalyzer.add(request, withObserver: resultsObserver)
            } catch {
                print(error.localizedDescription)
            }
            audioFileAnalyzer.analyze()
        } catch {
            print(error.localizedDescription)
        }
    }
    
}
