import SwiftUI

@main
struct MyApp: App {
    
    @State private var showAlert = true
    
    var body: some Scene {
        WindowGroup {
            WelcomeView()
                .preferredColorScheme(.dark)
                .alert(isPresented: $showAlert) {
                    Alert(title: Text("Orientation Warning"),
                          message: Text("Please use this app in landscape mode and if you change the orientation of the device please restart the app."),
                          dismissButton: .default(Text("OK")))
                }
        }
    }
}
