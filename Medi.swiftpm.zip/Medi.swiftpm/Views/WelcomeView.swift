import SwiftUI
import AVFoundation

struct WelcomeView: View {
    
    // MARK: Properties
    
    // Controlling the page navigation.
    @State var nextPage: Bool = false
    
    @State var audioPermissionAlert = true
    
    // MARK: Animation Properties
    @State var navigationButtonOpacity = 0.0
    
    // MARK: View
    var body: some View {
        VStack {
            Spacer()
            
            VStack(alignment: .leading, spacing: 0){
                //about the disease text section
                InfoView(subtitle: "Medi", subtitleColor: Color.mint, title: "Welcome", titleSize: 50, bodyIsOn: true, bodyText: "Medi, an AI powered tool is here to help us know about Aphasia disease and show how machine learning can diagnose Aphasia with a demo.", bodyTextColor: .white, bodyTextSize: 30, bodyPaddingTop: 20, bodyWidth: 800)
                
                //Card View
                HStack(spacing: 25) {
                    //What is Aphasia
                    
                    CardView(cardSymbolIsOn: true, cardSymbolName: "brain.head.profile", cardSymbolSize: 70, cardSymbolColor: .white, cardSymbolWidth: 250, cardSymbolHeight: 166, cardSubtitleIsOn: true, cardSubtitle: "What is", cardSubtitleSize: 15, cardSubtitleColor: .white, cardTitle: "Aphasia", cardTitleSize: 26, cardTitleColor: .white, paddingTop: 0, animationDuration: 0.6, width: 250, height: 250, cornerRadius: 40, backgroundColor: .mint)
                    
                    
                    //What is Medi card
                    CardView(cardSymbolIsOn: true, cardSymbolName: "hand.raised.fingers.spread.fill", cardSymbolSize: 70, cardSymbolColor: .white, cardSymbolWidth: 250, cardSymbolHeight: 166, cardSubtitleIsOn: true, cardSubtitle: "What is", cardSubtitleSize: 15, cardSubtitleColor: .white, cardTitle: "Medi? 🤔", cardTitleSize: 26, cardTitleColor: .white, paddingTop: 0, animationDuration: 0.7, width: 250, height: 250, cornerRadius: 40, backgroundColor: .mint)
                    
                    
                    //Medi Diagnosis card
                    CardView(cardSymbolIsOn: true, cardSymbolName: "stethoscope", cardSymbolSize: 70, cardSymbolColor: .white, cardSymbolWidth: 250, cardSymbolHeight: 166, cardSubtitleIsOn: false, cardSubtitle: "", cardSubtitleSize: 0, cardSubtitleColor: .white, cardTitle: "Diagnosis", cardTitleSize: 26, cardTitleColor: .white, paddingTop: 0, animationDuration: 0.0, width: 250, height: 250, cornerRadius: 40, backgroundColor: .mint)
                }
                .background(Group {
                    EmptyView()
                }, alignment: .center)
                .padding(.top, 60)
            }
            Spacer()
        
            //Navigation to next page through Get Started Button
            HStack(alignment: .bottom, spacing: 0){
                Spacer()
                Button("Get Started") {
                    withAnimation {
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color: .mint))
            }
            .padding(.leading, 20)
            .padding(.bottom, 20)
            .opacity(navigationButtonOpacity)
            .basicEaseIn(delayCount: 1, {
                navigationButtonOpacity = 1.0
            })
        }
        .navigationStack()
        .overlay(nextPage ? AboutAphasia() : nil)
        .onAppear {
            AVCaptureDevice.requestAccess(for: .audio) { isGranted in
                if isGranted == false {
                    audioPermissionAlert = false
                }
            }
        }
    }
}

struct WelcomeView_Previews: PreviewProvider {
    static var previews: some View {
        WelcomeView()
    }
}
