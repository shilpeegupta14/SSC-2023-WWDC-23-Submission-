//
//  File.swift
//
//
//  Created by Shilpee Gupta on 19/04/23.
//

import SwiftUI

struct AboutAphasia: View {
    // MARK: Properties
       
       // Controlling the page navigation.
       @State var nextPage: Bool = false
       
       // MARK: Animation Properties
       @State var backgroundOpacity = 0.0
       @State var navigationButtonOpacity = 0.0
       
       // MARK: View
       
        var body: some View {
            VStack {
                
                Spacer()
                
                HStack(spacing: 98) {
                    // The informational text which is appears on the center of the screen.
                    InfoView(subtitle: "What is", subtitleColor: .mint, title: "Aphasia?", titleSize: 50, bodyIsOn: true, bodyText: "Aphasia is a brain disorder where a person has trouble in reading and writing. This happens with damage or disruptions in parts of the brain that control spoken language. It often happens with conditions like stroke. The symptoms mostly involves trouble in reading and writing. It can affect people in different ways, and no two people will have the same changes or recovery.", bodyTextColor: .white, bodyTextSize: 20, bodyPaddingTop: 30, bodyWidth: 500)
                        .offset(x: -30, y: 0)
                    
                    
                    // The brain symbol with white background is assigned to the right side of the screen.
                    VStack(alignment: .trailing) {
                        Image(systemName: "brain.head.profile")
                            .font(.system(size: 120, weight: .bold, design: .default))
                            .foregroundColor(.white)
                            
                    }
                    .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                        .fill(Color.mint)
                        .frame(width: 300, height: 550, alignment: .trailing)
                        .clipped(), alignment: .center)
                }
                .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                        .fill(Color(.systemGray5))
                        .frame(width: 900, height: 550)
                        .clipped(), alignment: .center)
                .opacity(backgroundOpacity)
                .basicEaseIn(delayCount: 0) {
                    backgroundOpacity = 1.0
                }
                
                Spacer()
                
                // Navigation Button
                HStack(alignment: .bottom, spacing: 0) {
                    Spacer()
                    Button("Next") {
                        withAnimation {
                            nextPage = true
                        }
                    }
                    .buttonStyle(NavigationButtonStyle(color: Color(.systemGray5)))
                }
                .padding(.leading, 20)
                .padding(.bottom, 20)
                .opacity(navigationButtonOpacity)
                .basicEaseIn(delayCount: 0.6) {
                    navigationButtonOpacity = 1.0
                }
            }
            .navigationStack()
            .overlay(nextPage ? AboutMedi() : nil)
        }
    
}

struct AboutAphasia_Previews: PreviewProvider {
    
    static var previews: some View {
        AboutAphasia()
    }
}
