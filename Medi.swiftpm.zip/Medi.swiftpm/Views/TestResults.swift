//
//  File.swift
//
//
//  Created by Shilpee Gupta on 19/04/23.
//

import SwiftUI

struct TestResults: View {
    
    // MARK: Properties
    
    // OverallScoreCalculator Instance
    @ObservedObject var calculator = OverallScoreCalculator.shared
    
    // Controlling the page navigation.
    @State var nextPage: Bool = false
    
    // MARK: Animation Properties
    @State var backgroundOpacity = 0.0
    @State var titleOpacity = 0.0
    @State var infoTextsOpacity = 0.0
    @State var navigationButtonOpacity = 0.0
    
    // MARK: View
    
    var body: some View {
        VStack {
            
            Spacer()
            
            VStack(spacing: 0) {
                VStack(spacing: 0) {
                    
                    // Title
                    Text("👀 Your Test Results")
                        .font(.system(size: 50, weight: .bold, design: .default))
                        .foregroundColor(Color.white)
                        .padding(.top, 5)
                        .opacity(titleOpacity)
                        .basicEaseIn(delayCount: 0) {
                            titleOpacity = 1.0
                        }
                    
                    // Info Texts
                    VStack(spacing: 10) {
                        Text("Overall Result")
                            .font(.system(size: 30, weight: .semibold, design: .default))
                            .foregroundColor(Color.white)
                            .padding(.top, 5)
                        Text("\(calculator.calculate())% Aphasiaism")
                            .font(.system(size: 30, weight: .semibold, design: .default))
                            .foregroundColor(Color.mint)
                            .padding(.top, 5)
                    }
                    .padding(70)
                    .opacity(infoTextsOpacity)
                    .basicEaseIn(delayCount: 0.2) {
                        infoTextsOpacity = 1.0
                    }
                }
                
                // Test Results of Each Section
                HStack(spacing: 120) {
                    
                    // Speaking Test Result Card
                    CardView(cardSymbolIsOn: false, cardSymbolName: "", cardSymbolSize: 0, cardSymbolColor: .white, cardSymbolWidth: 0, cardSymbolHeight: 0, cardSubtitleIsOn: true, cardSubtitle: "Speaking Test" + "\n" + "Result:", cardSubtitleSize: 15, cardSubtitleColor: .white, cardTitle: "\(calculator.speakingTestResult)%", cardTitleSize: 40, cardTitleColor: .mint, paddingTop: 15, animationDuration: 0.6, width: 173, height: 173, cornerRadius: 47, backgroundColor: Color(.systemGray2))
                    
                    // Handwriting Test Result Card
                    CardView(cardSymbolIsOn: false, cardSymbolName: "", cardSymbolSize: 0, cardSymbolColor: .white, cardSymbolWidth: 0, cardSymbolHeight: 0, cardSubtitleIsOn: true, cardSubtitle: "Handwriting" + "\n" + "Test Result:", cardSubtitleSize: 15, cardSubtitleColor: .white, cardTitle: "\(calculator.handwritingTestResult)%", cardTitleSize: 40, cardTitleColor: .mint, paddingTop: 15, animationDuration: 0.8, width: 173, height: 173, cornerRadius: 47, backgroundColor: Color(.systemGray2))
                }
                .padding(.all, 20)
            }
            .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                .fill(Color(.systemGray5))
                .frame(width: 900, height: 550)
                .clipped(), alignment: .center)
            .frame(width: 900, height: 550, alignment: .center)
            .clipped()
            .cornerRadius(47)
            .opacity(backgroundOpacity)
            .basicEaseIn(delayCount: 0) {
                backgroundOpacity = 1.0
            }
            
            Spacer()
            
            // Navigation Button
            HStack(alignment: .bottom, spacing: 0) {
                Spacer()
                Button("Next") {
                    withAnimation {
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color: Color(.systemGray5)))
            }
            .padding(.leading, 20)
            .padding(.bottom, 20)
            .opacity(navigationButtonOpacity)
            .basicEaseIn(delayCount: 1) {
                navigationButtonOpacity = 1.0
            }
        }
        .navigationStack()
        .overlay(nextPage ? Thanks() : nil)
    }
    
}
struct TestResults_Previews: PreviewProvider {
    static var previews: some View {
        TestResults()
    }
}
